package usbmonitor;

import java.io.Serializable;
import java.util.Objects;

/** Immutable description of any USB device (storage, keyboard, mouse, camera ...). */
public class UsbDevice implements Serializable {
    private static final long serialVersionUID = 2L;

    private final String id;           // mount point ("E:\") or USB instance id / bus port
    private final String name;         // friendly name or volume label
    private final String deviceClass;  // Storage drive, Keyboard/Mouse (HID), Camera, Audio ...
    private final String manufacturer;
    private final String fileSystem;   // storage only
    private final String serial;
    private final long totalBytes;     // storage only (0 for other devices)

    public UsbDevice(String id, String name, String deviceClass, String manufacturer,
                     String fileSystem, String serial, long totalBytes) {
        this.id = id;
        this.name = blank(name) ? "(no name)" : name;
        this.deviceClass = blank(deviceClass) ? "Unknown" : deviceClass;
        this.manufacturer = blank(manufacturer) ? "" : manufacturer;
        this.fileSystem = blank(fileSystem) ? "" : fileSystem;
        this.serial = blank(serial) ? "N/A" : serial;
        this.totalBytes = totalBytes;
    }

    /** Convenience constructor for storage drives. */
    public UsbDevice(String mountPoint, String label, String fileSystem, String serial, long totalBytes) {
        this(mountPoint, blank(label) ? "(no label)" : label, "Storage drive", "",
                blank(fileSystem) ? "unknown" : fileSystem, serial, totalBytes);
    }

    private static boolean blank(String s) { return s == null || s.isBlank(); }

    public String getMountPoint()   { return id; }
    public String getLabel()        { return name; }
    public String getDeviceClass()  { return deviceClass; }
    public String getManufacturer() { return manufacturer; }
    public String getFileSystem()   { return fileSystem; }
    public String getSerial()       { return serial; }
    public long getTotalBytes()     { return totalBytes; }
    public boolean isStorage()      { return deviceClass.equals("Storage drive"); }

    /** Converts a byte count to a readable string such as "14.9 GB". */
    public static String humanSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        String[] units = {"KB", "MB", "GB", "TB"};
        double v = bytes;
        int i = -1;
        while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
        return String.format("%.1f %s", v, units[i]);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof UsbDevice)) return false;
        UsbDevice d = (UsbDevice) o;
        return id.equals(d.id) && serial.equals(d.serial);
    }

    @Override
    public int hashCode() { return Objects.hash(id, serial); }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(id).append(" | ").append(name).append(" | type=").append(deviceClass);
        if (!manufacturer.isEmpty()) sb.append(" | maker=").append(manufacturer);
        if (totalBytes > 0) sb.append(" | fs=").append(fileSystem).append(" | size=").append(humanSize(totalBytes));
        sb.append(" | serial=").append(serial);
        return sb.toString();
    }
}
