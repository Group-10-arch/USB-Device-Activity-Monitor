package usbmonitor;

import java.io.*;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Listener that (1) appends each event to a text log, and (2) keeps an in-memory
 * history that can be saved/loaded with Java object serialization.
 */
public class EventLogger implements UsbEventListener {
    private final Path logFile;
    private final Path historyFile;
    private final List<UsbEvent> history = Collections.synchronizedList(new ArrayList<>());

    public EventLogger(String folder) {
        Path dir = Paths.get(folder);
        try { Files.createDirectories(dir); }
        catch (IOException e) { System.err.println("Cannot create log folder: " + e.getMessage()); }
        logFile = dir.resolve("usb_activity.log");
        historyFile = dir.resolve("history.ser");
        loadHistory();
    }

    @Override
    public void onEvent(UsbEvent event) {
        history.add(event);
        writeLine(event.toString());
    }

    private synchronized void writeLine(String line) {
        try (BufferedWriter w = Files.newBufferedWriter(logFile,
                StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
            w.write(line);
            w.newLine();
        } catch (IOException e) {
            System.err.println("Could not write log: " + e.getMessage());
        }
    }

    public List<UsbEvent> getHistory() {
        synchronized (history) { return new ArrayList<>(history); }
    }

    /** Case-insensitive search across type, label, mount point, serial and time (uses streams). */
    public List<UsbEvent> search(String keyword) {
        String k = keyword.toLowerCase();
        return getHistory().stream()
                .filter(e -> e.toString().toLowerCase().contains(k))
                .collect(Collectors.toList());
    }

    public long count(EventType type) {
        return getHistory().stream().filter(e -> e.getType() == type).count();
    }

    public void clearHistory() { history.clear(); saveHistory(); }

    public void saveHistory() {
        try (ObjectOutputStream out = new ObjectOutputStream(Files.newOutputStream(historyFile))) {
            out.writeObject(getHistory());
        } catch (IOException e) {
            System.err.println("Could not save history: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void loadHistory() {
        if (!Files.exists(historyFile)) return;
        try (ObjectInputStream in = new ObjectInputStream(Files.newInputStream(historyFile))) {
            history.addAll((List<UsbEvent>) in.readObject());
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Could not load history (starting fresh): " + e.getMessage());
        }
    }

    /** Writes the history to a CSV file the user can open in Excel. */
    public void exportCsv(File target) throws IOException {
        try (PrintWriter w = new PrintWriter(new FileWriter(target))) {
            w.println("Time,Event,Type,Name,Id,Manufacturer,FileSystem,Size,Serial");
            for (UsbEvent e : getHistory()) {
                UsbDevice d = e.getDevice();
                w.printf("%s,%s,\"%s\",\"%s\",\"%s\",\"%s\",%s,%s,%s%n", e.getTimeString(), e.getType(),
                        d.getDeviceClass(), d.getLabel(), d.getMountPoint(), d.getManufacturer(),
                        d.getFileSystem(), d.getTotalBytes() > 0 ? UsbDevice.humanSize(d.getTotalBytes()) : "-", d.getSerial());
            }
        }
    }
}
