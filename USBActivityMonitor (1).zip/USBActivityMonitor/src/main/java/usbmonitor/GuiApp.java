package usbmonitor;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;

/** Simple Swing interface: live event table, start/stop, simulate buttons, inspect and export. */
public class GuiApp extends JFrame implements UsbEventListener {
    private final EventLogger logger = new EventLogger("logs");
    private final UsbMonitor monitor = new UsbMonitor(3000);
    private final DefaultTableModel model = new DefaultTableModel(
            new String[]{"Time", "Event", "Type", "Name", "ID / Mount", "Manufacturer", "Size", "Serial"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable table = new JTable(model);
    private final JLabel status = new JLabel("Monitor stopped");
    private final JLabel counts = new JLabel();

    public GuiApp() {
        super("USB Device Activity Monitor");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(900, 480);
        setLocationRelativeTo(null);

        monitor.addListener(logger);
        monitor.addListener(this);

        JButton start = new JButton("Start");
        JButton stop = new JButton("Stop");
        JButton plug = new JButton("Simulate Plug-in");
        JButton unplug = new JButton("Simulate Removal");
        JButton inspect = new JButton("Inspect Selected");
        JButton export = new JButton("Export CSV");
        JButton clear = new JButton("Clear History");

        start.addActionListener(e -> { monitor.start(); status.setText("Monitoring... (checks every 3s)"); });
        stop.addActionListener(e -> { monitor.stop(); status.setText("Monitor stopped"); });
        plug.addActionListener(e -> { monitor.start(); status.setText("Monitoring... (checks every 3s)"); monitor.simulatePlugIn(); });
        unplug.addActionListener(e -> monitor.simulateRemoveAll());
        inspect.addActionListener(e -> inspectSelected());
        export.addActionListener(e -> exportCsv());
        clear.addActionListener(e -> {
            if (JOptionPane.showConfirmDialog(this, "Delete all saved history?", "Confirm",
                    JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                logger.clearHistory(); model.setRowCount(0); updateCounts();
            }
        });

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        for (JButton b : new JButton[]{start, stop, plug, unplug, inspect, export, clear}) top.add(b);

        JPanel bottom = new JPanel(new BorderLayout());
        bottom.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));
        bottom.add(status, BorderLayout.WEST);
        bottom.add(counts, BorderLayout.EAST);

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
        add(bottom, BorderLayout.SOUTH);

        for (UsbEvent ev : logger.getHistory()) addRow(ev); // show saved history
        updateCounts();

        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override public void windowClosing(java.awt.event.WindowEvent e) {
                monitor.stop(); logger.saveHistory();
            }
        });
    }

    /** Called from the monitor thread, so hop onto the Swing thread before touching the UI. */
    @Override
    public void onEvent(UsbEvent ev) {
        SwingUtilities.invokeLater(() -> { addRow(ev); updateCounts(); });
    }

    private void addRow(UsbEvent ev) {
        UsbDevice d = ev.getDevice();
        model.addRow(new Object[]{ev.getTimeString(), ev.getType(), d.getDeviceClass(), d.getLabel(),
                d.getMountPoint(), d.getManufacturer(),
                d.getTotalBytes() > 0 ? UsbDevice.humanSize(d.getTotalBytes()) : "-", d.getSerial()});
    }

    private void updateCounts() {
        counts.setText("Connected: " + logger.count(EventType.CONNECTED)
                + "   Removed: " + logger.count(EventType.REMOVED));
    }

    private void inspectSelected() {
        int row = table.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Select a row first."); return; }
        File f = new File(String.valueOf(model.getValueAt(row, 4)));
        if (!f.isDirectory()) {
            JOptionPane.showMessageDialog(this, "Only connected storage drives can be inspected.");
            return;
        }
        // Run the recursive scan off the UI thread so the window doesn't freeze.
        new SwingWorker<DeviceInspector.Stats, Void>() {
            @Override protected DeviceInspector.Stats doInBackground() { return DeviceInspector.inspect(f, 10); }
            @Override protected void done() {
                try { JOptionPane.showMessageDialog(GuiApp.this, f + "\n" + get()); }
                catch (Exception ex) { JOptionPane.showMessageDialog(GuiApp.this, "Scan failed: " + ex.getMessage()); }
            }
        }.execute();
    }

    private void exportCsv() {
        JFileChooser fc = new JFileChooser();
        fc.setSelectedFile(new File("usb_history.csv"));
        if (fc.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            try { logger.exportCsv(fc.getSelectedFile()); JOptionPane.showMessageDialog(this, "Exported."); }
            catch (java.io.IOException ex) { JOptionPane.showMessageDialog(this, "Export failed: " + ex.getMessage()); }
        }
    }

    public static void run() {
        SwingUtilities.invokeLater(() -> new GuiApp().setVisible(true));
    }
}
