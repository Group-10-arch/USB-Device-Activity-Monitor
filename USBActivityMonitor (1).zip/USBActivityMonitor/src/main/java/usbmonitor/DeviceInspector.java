package usbmonitor;

import java.io.File;

/** Uses RECURSION to walk the folder tree of a device and total up files and bytes. */
public class DeviceInspector {
    public static class Stats {
        public long files, folders, bytes;
        @Override public String toString() {
            return files + " files, " + folders + " folders, " + UsbDevice.humanSize(bytes);
        }
    }

    /** Public entry point. maxDepth protects against huge drives / endless loops. */
    public static Stats inspect(File root, int maxDepth) {
        Stats s = new Stats();
        walk(root, 0, maxDepth, s);
        return s;
    }

    // Time complexity O(n) where n = number of files/folders visited.
    private static void walk(File dir, int depth, int maxDepth, Stats s) {
        if (depth > maxDepth) return;
        File[] children = dir.listFiles();
        if (children == null) return; // unreadable folder: skip it safely
        for (File f : children) {
            if (f.isDirectory()) {
                s.folders++;
                walk(f, depth + 1, maxDepth, s);   // recursive step
            } else {
                s.files++;
                s.bytes += f.length();
            }
        }
    }
}
