package usbmonitor;

import java.awt.GraphicsEnvironment;
import javax.swing.JOptionPane;

/** Program entry point. Asks whether to run the GUI or the console menu. */
public class Main {
    public static void main(String[] args) {
        boolean cli = args.length > 0 && args[0].equalsIgnoreCase("cli");
        if (!cli && !GraphicsEnvironment.isHeadless()) {
            Object[] options = {"GUI", "Console (CLI)"};
            int c = JOptionPane.showOptionDialog(null, "How do you want to run the USB Monitor?",
                    "USB Device Activity Monitor", JOptionPane.DEFAULT_OPTION,
                    JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
            if (c == 0) { GuiApp.run(); return; }
            if (c == -1) return; // dialog closed
        }
        CliApp.run();
    }
}
