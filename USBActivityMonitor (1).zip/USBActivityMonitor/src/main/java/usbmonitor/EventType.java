package usbmonitor;

/** The kinds of USB activity the monitor can record. */
public enum EventType {
    CONNECTED, REMOVED
}
