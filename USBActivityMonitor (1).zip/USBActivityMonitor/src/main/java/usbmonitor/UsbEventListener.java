package usbmonitor;

/** Observer interface: anything that wants to be told about USB events implements this. */
public interface UsbEventListener {
    void onEvent(UsbEvent event);
}
