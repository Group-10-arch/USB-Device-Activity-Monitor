package usbmonitor;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** One entry in the activity history: what happened, to which device, and when. */
public class UsbEvent implements Serializable {
    private static final long serialVersionUID = 1L;
    public static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private final EventType type;
    private final UsbDevice device;
    private final LocalDateTime time;

    public UsbEvent(EventType type, UsbDevice device) {
        this.type = type;
        this.device = device;
        this.time = LocalDateTime.now();
    }

    public EventType getType()    { return type; }
    public UsbDevice getDevice()  { return device; }
    public LocalDateTime getTime(){ return time; }
    public String getTimeString() { return time.format(FMT); }

    @Override
    public String toString() {
        return "[" + getTimeString() + "] " + type + " -> " + device;
    }
}
