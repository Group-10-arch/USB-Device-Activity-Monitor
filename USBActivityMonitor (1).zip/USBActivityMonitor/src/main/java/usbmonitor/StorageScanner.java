package usbmonitor;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/**
 * Finds removable STORAGE drives (flash drives, external disks) and their details.
 *
 * Windows: walks the drive letters (cheap) and asks PowerShell for details only the
 *          first time a new letter appears. Fixed disks are remembered and ignored.
 * Linux/macOS: looks inside the usual mount folders (/media, /run/media, /Volumes).
 */
public class StorageScanner implements DeviceScanner {
    private final boolean windows = System.getProperty("os.name").toLowerCase().contains("win");
    private final Set<String> ignored = new HashSet<>();          // fixed/optical drives
    private final Map<String, UsbDevice> cache = new HashMap<>(); // details already looked up

    @Override
    public Map<String, UsbDevice> scan() {
        Map<String, UsbDevice> result = new LinkedHashMap<>();
        if (windows) scanWindows(result); else scanUnix(result);
        return result;
    }

    // ---------------------------------------------------------------- Windows
    private void scanWindows(Map<String, UsbDevice> result) {
        Set<String> present = new HashSet<>();
        for (File root : File.listRoots()) {
            String key = root.getAbsolutePath();       // "E:\"
            present.add(key);
            if (ignored.contains(key)) continue;
            if (root.getTotalSpace() == 0) continue;   // empty card reader / no media
            UsbDevice d = cache.get(key);
            if (d == null) {
                d = queryWindowsDrive(key);
                if (d == null) { ignored.add(key); continue; }
                cache.put(key, d);
            }
            result.put(key, d);
        }
        // forget drives that have disappeared so a re-plugged drive is queried again
        ignored.retainAll(present);
        cache.keySet().retainAll(present);
    }

    private UsbDevice queryWindowsDrive(String root) {
        String id = root.substring(0, 2); // "E:"
        String ps = "Get-CimInstance Win32_LogicalDisk | Where-Object { $_.DeviceID -eq '" + id + "' } | "
                  + "ForEach-Object { Write-Output ($_.DriveType.ToString() + '|' + $_.VolumeName + '|' + "
                  + "$_.FileSystem + '|' + $_.Size + '|' + $_.VolumeSerialNumber) }";
        try {
            ProcessBuilder pb = new ProcessBuilder("powershell", "-NoProfile", "-Command", ps);
            pb.redirectErrorStream(true);
            Process p = pb.start();
            String line;
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                line = r.readLine();
            }
            p.waitFor();
            if (line == null) return null;
            String[] f = line.split("\\|", -1);
            if (f.length < 5 || !f[0].trim().equals("2")) return null; // 2 = removable disk
            long size = 0;
            try { size = Long.parseLong(f[3].trim()); } catch (NumberFormatException ignoredEx) { }
            return new UsbDevice(root, f[1].trim(), f[2].trim(), f[4].trim(), size);
        } catch (IOException | InterruptedException e) {
            System.err.println("Could not query drive " + root + ": " + e.getMessage());
            return null;
        }
    }

    // ----------------------------------------------------------- Linux / macOS
    private void scanUnix(Map<String, UsbDevice> result) {
        String user = System.getProperty("user.name");
        String[] bases = {"/media/" + user, "/run/media/" + user, "/Volumes"};
        for (String b : bases) {
            File[] dirs = new File(b).listFiles(File::isDirectory);
            if (dirs == null) continue;
            for (File d : dirs) {
                if (java.nio.file.Files.isSymbolicLink(d.toPath())) continue; // skips macOS "Macintosh HD"
                String key = d.getAbsolutePath();
                result.put(key, new UsbDevice(key, d.getName(), "unknown", "N/A", d.getTotalSpace()));
            }
        }
    }
}
