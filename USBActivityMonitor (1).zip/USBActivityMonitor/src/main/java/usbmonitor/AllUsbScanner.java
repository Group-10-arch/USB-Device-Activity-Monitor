package usbmonitor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.*;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Stream;

/**
 * Detects EVERY USB device (keyboards, mice, webcams, headsets, phones, drives ...).
 *
 * Windows : PowerShell Get-PnpDevice (devices whose instance id starts with USB\VID_)
 * Linux   : reads /sys/bus/usb/devices (pure Java, no commands needed)
 * macOS   : parses the output of "ioreg -p IOUSB"
 */
public class AllUsbScanner implements DeviceScanner {
    private final String os = System.getProperty("os.name").toLowerCase();
    private Map<String, UsbDevice> lastGood = new HashMap<>();

    @Override
    public Map<String, UsbDevice> scan() {
        Map<String, UsbDevice> r = null;
        if (os.contains("win")) r = scanWindows();
        else if (os.contains("mac")) r = scanMac();
        else r = scanLinux();
        if (r == null) return lastGood;   // lookup failed: reuse last result so we don't fake "removed" events
        lastGood = r;
        return r;
    }

    // ---------------------------------------------------------------- Windows
    private Map<String, UsbDevice> scanWindows() {
        String ps = "Get-PnpDevice -PresentOnly | Where-Object { $_.InstanceId -like 'USB\\VID_*' "
                  + "-and $_.InstanceId -notlike '*&MI_*' } | ForEach-Object { Write-Output "
                  + "($_.InstanceId + '|' + $_.FriendlyName + '|' + $_.Class + '|' + $_.Manufacturer) }";
        Map<String, UsbDevice> out = new LinkedHashMap<>();
        try {
            ProcessBuilder pb = new ProcessBuilder("powershell", "-NoProfile", "-Command", ps);
            pb.redirectErrorStream(true);
            Process p = pb.start();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String line;
                while ((line = r.readLine()) != null) {
                    String[] f = line.split("\\|", -1);
                    if (f.length < 4 || !f[0].toUpperCase().startsWith("USB\\VID_")) continue;
                    String instanceId = f[0].trim();
                    String serial = instanceId.substring(instanceId.lastIndexOf('\\') + 1);
                    String cls = friendlyClass(f[2].trim());
                    String name = f[1].trim().isEmpty() ? cls : f[1].trim();
                    out.put(instanceId, new UsbDevice(instanceId, name, cls, f[3].trim(), "", serial, 0));
                }
            }
            p.waitFor();
        } catch (IOException | InterruptedException e) {
            return null;
        }
        return out;
    }

    private static String friendlyClass(String c) {
        switch (c.toLowerCase()) {
            case "hidclass":    return "Input device (HID)";
            case "keyboard":    return "Keyboard";
            case "mouse":       return "Mouse";
            case "diskdrive":   return "Storage drive";
            case "image":
            case "camera":      return "Camera";
            case "media":
            case "audioendpoint": return "Audio";
            case "bluetooth":   return "Bluetooth";
            case "printer":     return "Printer";
            case "usb":         return "USB device";
            default:            return c.isEmpty() ? "USB device" : c;
        }
    }

    // ------------------------------------------------------------------ Linux
    private Map<String, UsbDevice> scanLinux() {
        Path base = Paths.get("/sys/bus/usb/devices");
        if (!Files.isDirectory(base)) return null;
        Map<String, UsbDevice> out = new LinkedHashMap<>();
        try (Stream<Path> dirs = Files.list(base)) {
            for (Path d : (Iterable<Path>) dirs::iterator) {
                String n = d.getFileName().toString();
                if (n.contains(":") || n.startsWith("usb")) continue; // skip interfaces and root hubs
                String vid = read(d, "idVendor"), pid = read(d, "idProduct");
                if (vid.isEmpty()) continue;
                String cls = classFromHex(read(d, "bDeviceClass"), d, n);
                if (cls.equals("Hub")) continue;
                String name = read(d, "product");
                if (name.isEmpty()) name = "USB device " + vid + ":" + pid;
                out.put(n, new UsbDevice(n + " [" + vid + ":" + pid + "]", name, cls,
                        read(d, "manufacturer"), "", read(d, "serial"), 0));
            }
        } catch (IOException e) {
            return null;
        }
        return out;
    }

    private static String read(Path dir, String file) {
        try { return Files.readString(dir.resolve(file)).trim(); }
        catch (IOException e) { return ""; }
    }

    private static String classFromHex(String hex, Path dir, String n) {
        if (hex.equals("00")) hex = read(dir.getParent().resolve(n + ":1.0"), "bInterfaceClass"); // class lives on the interface
        switch (hex) {
            case "01": return "Audio";
            case "03": return "Input device (HID)";
            case "06": return "Camera";
            case "07": return "Printer";
            case "08": return "Storage drive";
            case "09": return "Hub";
            case "0e": return "Camera";
            case "e0": return "Wireless/Bluetooth";
            default:   return "USB device";
        }
    }

    // ------------------------------------------------------------------ macOS
    private Map<String, UsbDevice> scanMac() {
        Map<String, UsbDevice> out = new LinkedHashMap<>();
        try {
            Process p = new ProcessBuilder("ioreg", "-p", "IOUSB", "-w0").redirectErrorStream(true).start();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String line;
                while ((line = r.readLine()) != null) {
                    int o = line.indexOf("+-o ");
                    int at = line.indexOf('@');
                    int end = line.indexOf("  <");
                    if (o < 0 || at < o || end < at || !line.contains("IOUSB")) continue;
                    String name = line.substring(o + 4, at).trim();
                    String loc = line.substring(at + 1, end).trim();
                    if (name.toLowerCase().contains("root hub")) continue;
                    out.put(loc, new UsbDevice(loc, name, "USB device", "", "", loc, 0));
                }
            }
            p.waitFor();
        } catch (IOException | InterruptedException e) {
            return null;
        }
        return out;
    }
}
