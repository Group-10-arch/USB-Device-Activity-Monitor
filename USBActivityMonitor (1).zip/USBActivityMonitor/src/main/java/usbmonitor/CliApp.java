package usbmonitor;

import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/** Console menu used to test the monitor. */
public class CliApp {
    public static void run() {
        EventLogger logger = new EventLogger("logs");
        UsbMonitor monitor = new UsbMonitor(3000);
        monitor.addListener(logger);
        monitor.addListener(e -> System.out.println("\n>>> LIVE: " + e));

        Scanner in = new Scanner(System.in);
        boolean exit = false;
        while (!exit) {
            System.out.println("\n===== USB DEVICE ACTIVITY MONITOR =====");
            System.out.println("Monitor is " + (monitor.isRunning() ? "RUNNING" : "STOPPED"));
            System.out.println("1. Start monitoring");
            System.out.println("2. Stop monitoring");
            System.out.println("3. Show connected devices");
            System.out.println("4. Show activity history");
            System.out.println("5. Search history");
            System.out.println("6. Inspect a connected device (recursive scan)");
            System.out.println("7. Simulate plug-in");
            System.out.println("8. Simulate removal");
            System.out.println("9. Save history / export CSV");
            System.out.println("0. Exit");
            System.out.print("Choose: ");
            String choice = in.nextLine().trim();
            switch (choice) {
                case "1": monitor.start(); System.out.println("Monitoring started (checks every 3s)."); break;
                case "2": monitor.stop();  System.out.println("Monitoring stopped."); break;
                case "3": {
                    Map<String, UsbDevice> m = monitor.getConnected();
                    if (m.isEmpty()) System.out.println("No USB devices connected (or monitor not started).");
                    m.values().forEach(d -> System.out.println(" - " + d));
                    break;
                }
                case "4": {
                    List<UsbEvent> h = logger.getHistory();
                    if (h.isEmpty()) System.out.println("History is empty.");
                    h.forEach(System.out::println);
                    System.out.println("Totals: " + logger.count(EventType.CONNECTED) + " connected, "
                            + logger.count(EventType.REMOVED) + " removed.");
                    break;
                }
                case "5": {
                    System.out.print("Keyword: ");
                    List<UsbEvent> r = logger.search(in.nextLine().trim());
                    System.out.println(r.size() + " match(es):");
                    r.forEach(System.out::println);
                    break;
                }
                case "6": {
                    System.out.print("Mount point (e.g. E:\\): ");
                    File f = new File(in.nextLine().trim());
                    if (!f.isDirectory()) { System.out.println("That path is not a readable folder."); break; }
                    System.out.println("Scanning... " + DeviceInspector.inspect(f, 10));
                    break;
                }
                case "7": monitor.start(); System.out.println("Simulated: " + monitor.simulatePlugIn()); break;
                case "8": monitor.simulateRemoveAll(); System.out.println("Simulated devices removed."); break;
                case "9": {
                    logger.saveHistory();
                    try { logger.exportCsv(new File("logs/usb_history.csv")); System.out.println("Saved to logs/ folder."); }
                    catch (java.io.IOException e) { System.out.println("Export failed: " + e.getMessage()); }
                    break;
                }
                case "0": exit = true; break;
                default: System.out.println("Invalid option, try again.");
            }
        }
        monitor.stop();
        logger.saveHistory();
        System.out.println("Goodbye.");
    }
}
