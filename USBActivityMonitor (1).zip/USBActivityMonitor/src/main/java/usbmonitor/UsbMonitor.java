package usbmonitor;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Background worker (its own thread) that polls the scanner and compares the new
 * snapshot with the previous one. Differences become CONNECTED / REMOVED events.
 *
 * Complexity: each poll is O(n) in the number of drives thanks to HashMap lookups.
 */
public class UsbMonitor implements Runnable {
    // every scanner contributes devices; results are merged into one snapshot
    private final List<DeviceScanner> scanners = List.of(new AllUsbScanner(), new StorageScanner());
    private final List<UsbEventListener> listeners = new CopyOnWriteArrayList<>();
    private final Map<String, UsbDevice> simulated = new ConcurrentHashMap<>();
    private Map<String, UsbDevice> current = new HashMap<>();
    private final long intervalMs;
    private volatile boolean running = false;
    private Thread thread;
    private int simCounter = 0;

    public UsbMonitor(long intervalMs) { this.intervalMs = intervalMs; }

    public void addListener(UsbEventListener l) { listeners.add(l); }

    public synchronized void start() {
        if (running) return;
        running = true;
        thread = new Thread(this, "usb-monitor");
        thread.setDaemon(true);
        thread.start();
    }

    public synchronized void stop() {
        running = false;
        if (thread != null) thread.interrupt();
    }

    public boolean isRunning() { return running; }

    @Override
    public void run() {
        while (running) {
            try {
                poll();
                Thread.sleep(intervalMs);
            } catch (InterruptedException e) {
                break;
            } catch (RuntimeException e) {
                System.err.println("Monitor error: " + e.getMessage()); // keep the thread alive
            }
        }
    }

    /** Compare the new snapshot with the old one and fire events for the differences. */
    private synchronized void poll() {
        Map<String, UsbDevice> now = new HashMap<>();
        for (DeviceScanner sc : scanners) now.putAll(sc.scan());
        now.putAll(simulated);

        for (Map.Entry<String, UsbDevice> e : now.entrySet())
            if (!current.containsKey(e.getKey())) fire(new UsbEvent(EventType.CONNECTED, e.getValue()));

        for (Map.Entry<String, UsbDevice> e : current.entrySet())
            if (!now.containsKey(e.getKey())) fire(new UsbEvent(EventType.REMOVED, e.getValue()));

        current = now;
    }

    private void fire(UsbEvent ev) {
        for (UsbEventListener l : listeners) l.onEvent(ev);
    }

    public synchronized Map<String, UsbDevice> getConnected() { return new HashMap<>(current); }

    // ------------------------------------------------------ demo / testing helpers
    /** Pretend a USB device was plugged in. Cycles through different device types. */
    public synchronized UsbDevice simulatePlugIn() {
        simCounter++;
        String[][] kinds = {
            {"Flash drive", "Storage drive", "SimDisk Inc."},
            {"USB Keyboard", "Keyboard", "SimTech"},
            {"Optical Mouse", "Mouse", "SimTech"},
            {"HD Webcam", "Camera", "SimVision"},
            {"USB Headset", "Audio", "SimSound"}};
        String[] k = kinds[(simCounter - 1) % kinds.length];
        String id = "SIM\\VID_" + String.format("%04X", 0x1000 + simCounter) + "\\" + simCounter;
        long size = k[1].equals("Storage drive") ? 16L * 1024 * 1024 * 1024 : 0;
        UsbDevice d = new UsbDevice(id, k[0] + " " + simCounter, k[1], k[2],
                size > 0 ? "FAT32" : "", String.format("%08X", 0xA1B20000 + simCounter), size);
        simulated.put(id, d);
        poll();
        return d;
    }

    /** Remove all simulated devices. */
    public synchronized void simulateRemoveAll() {
        simulated.clear();
        poll();
    }
}
