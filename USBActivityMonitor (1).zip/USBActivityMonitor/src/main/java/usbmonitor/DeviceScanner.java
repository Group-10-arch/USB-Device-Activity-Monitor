package usbmonitor;

import java.util.Map;

/** Strategy interface: each implementation knows one way of discovering devices. */
public interface DeviceScanner {
    /** @return map of unique key -> device for everything this scanner can see right now. */
    Map<String, UsbDevice> scan();
}
